package com.example.hp.muxi_workbench_android.base;


import androidx.appcompat.app.AppCompatActivity;

public class BaseActivity extends AppCompatActivity {
}
